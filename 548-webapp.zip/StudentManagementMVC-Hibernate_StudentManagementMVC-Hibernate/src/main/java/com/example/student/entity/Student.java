package com.example.student.entity;

import javax.persistence.*;

@Entity
@Table(name = "Student")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String rollNo;
    
    // Add the 'email' field
    @Column(nullable = false)
    private String email;

    // Add the 'section' field
    @Column(nullable = false)
    private String section;

    public Student() {}

    public Student(String name, String rollNo, String email, String section) {
        this.name = name;
        this.rollNo = rollNo;
        this.email = email;
        this.section = section;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }
    
    // Getter and Setter for 'email'
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    // Getter and Setter for 'section'
    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }
}