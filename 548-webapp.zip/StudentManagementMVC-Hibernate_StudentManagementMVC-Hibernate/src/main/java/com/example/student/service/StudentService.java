package com.example.student.service;

import com.example.student.dao.StudentDao;
import com.example.student.entity.Student;

import java.util.List;

public class StudentService {
    private final StudentDao dao = new StudentDao();

    public void create(String name, String rollNo) {
        dao.save(new Student(name, rollNo));
    }

    public void update(Long id, String name, String rollNo) {
        Student s = dao.findById(id);
        if (s != null) {
            s.setName(name);
            s.setRollNo(rollNo);
            dao.update(s);
        }
    }

    public void delete(Long id) {
        dao.delete(id);
    }

    public Student get(Long id) {
        return dao.findById(id);
    }

    public List<Student> list() {
        return dao.findAll();
    }
}
