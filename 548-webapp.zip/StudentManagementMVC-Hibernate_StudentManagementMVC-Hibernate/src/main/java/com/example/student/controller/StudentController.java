package com.example.student.controller;

import com.example.student.service.StudentService;
import com.example.student.entity.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/students")
public class StudentController extends HttpServlet {

    private final StudentService service = new StudentService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null || action.equals("list")) {
            req.setAttribute("students", service.list());
            req.getRequestDispatcher("/WEB-INF/views/list.jsp").forward(req, resp);
        } else if (action.equals("edit")) {
            Long id = Long.parseLong(req.getParameter("id"));
            req.setAttribute("student", service.get(id));
            req.getRequestDispatcher("/WEB-INF/views/form.jsp").forward(req, resp);
        } else if (action.equals("new")) {
            req.getRequestDispatcher("/WEB-INF/views/form.jsp").forward(req, resp);
        } else if (action.equals("delete")) {
            Long id = Long.parseLong(req.getParameter("id"));
            service.delete(id);
            resp.sendRedirect(req.getContextPath() + "/students");
        } else {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idStr = req.getParameter("id");
        String name = req.getParameter("name");
        String rollNo = req.getParameter("rollNo");

        if (idStr == null || idStr.isEmpty()) {
            service.create(name, rollNo);
        } else {
            Long id = Long.parseLong(idStr);
            service.update(id, name, rollNo);
        }
        resp.sendRedirect(req.getContextPath() + "/students");
    }
}
