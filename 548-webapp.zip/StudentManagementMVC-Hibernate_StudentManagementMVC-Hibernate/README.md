# StudentManagementMVC-Hibernate

Simple MVC (Servlet/JSP) + Hibernate CRUD webapp for `Student` (name, rollNo). Uses in-memory H2 for quick start.

## Run

1. Import as Maven project in IDE (IntelliJ/Eclipse) or build with:
   ```bash
   mvn clean package
   ```
2. Deploy the generated WAR to a servlet container (Tomcat 9+).
3. Open `http://localhost:8080/StudentManagementMVC-Hibernate/students`

## Switch to MySQL

Edit `src/main/resources/hibernate.cfg.xml`:
- Change dialect to `org.hibernate.dialect.MySQL8Dialect`
- Change connection properties:
  ```xml
  <property name="hibernate.connection.driver_class">com.mysql.cj.jdbc.Driver</property>
  <property name="hibernate.connection.url">jdbc:mysql://localhost:3306/studentdb?useSSL=false&serverTimezone=UTC</property>
  <property name="hibernate.connection.username">root</property>
  <property name="hibernate.connection.password">password</property>
  ```

Create the DB first:
```sql
CREATE DATABASE studentdb CHARACTER SET utf8mb4;
```

## Endpoints
- `GET /students` - list
- `GET /students?action=new` - create form
- `GET /students?action=edit&id={id}` - edit form
- `GET /students?action=delete&id={id}` - delete
- `POST /students` - create/update
